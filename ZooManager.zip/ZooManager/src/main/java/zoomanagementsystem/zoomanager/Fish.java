package zoomanagementsystem.zoomanager;

public class Fish extends Animal implements Swimmable
{
    double length;   
    double bodyDepth;
    
    
    public Fish (String types, String name, int age, String gender, double weight, double length, double bodyDepth, String habitat)
    {
        super (types,name,age,gender,weight,habitat);
        this.length = length;
        this.bodyDepth = bodyDepth;
    }

    @Override
    void makeSound() 
    {
        System.out.println( types +  " make a weird sound");
    }

    @Override
    void sleep() 
    {
        System.out.println( types + " is sleeping");
    }

    @Override
    void eat() 
    {
     System.out.println( types + " is eating");  
    }

    @Override
    public void swim() 
    {
        System.out.println( types + " swum");
    }
}
