package zoomanagementsystem.zoomanager;

public class Bird extends Animal implements Flyable 
{
    double wingSpan;
    String featherColor;
    
    public Bird (String types, String name, int age, String gender, double weight, double wingSpan, String featherColor, String habitat)
    {
        super (types,name,age,gender,weight,habitat);
        this.wingSpan = wingSpan;
        this.featherColor = featherColor;
    }
    
    @Override
    void makeSound() 
    {
        System.out.println( types + " can tweet");  
    }

    @Override
    void sleep() 
    {
        System.out.println( types + " can sleep 6 to 12 hours");
    }

    @Override
    void eat() 
    {
        System.out.println( types + " can eat insects");
    }

    @Override
    public void fly() 
    {
       System.out.println( types + " is flying in the sky"); 
    }
    
}
