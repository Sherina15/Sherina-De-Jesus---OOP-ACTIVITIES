package zoomanagementsystem.zoomanager;

public interface Walking 
{
    void walk();
}
