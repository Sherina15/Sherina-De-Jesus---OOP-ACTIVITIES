package zoomanagementsystem.zoomanager;

import java.util.ArrayList;
import java.util.Scanner;

public class ZooManager 
{
     static ArrayList <Animal> zooAnimals = new ArrayList<>();
    
    public static void main(String[] args)       
    {
    anotherTransaction();
    }
        public static void  anotherTransaction()
        {
            Scanner in = new Scanner(System.in);         
            
            int transac;
            String habitat;
            int addAgain;   

           System.out.println ("=============================");
           System.out.println ("Do you want to start the Program? ");
           System.out.println ("1. YES"); 
           System.out.println ("2. NO");
           transac = in.nextInt();
           System.out.println();
           System.out.println ("=============================");
     
           int choice;
         
        if (transac == 1 )
        {

            System.out.println ("    ZOO MANAGEMENT SYSTEM     ");
            System.out.println ("=============================");
            System.out.println ("1. Add an Animal");
            System.out.println ("2. View All Animals in the Zoo");
            System.out.println ("3. View Animal in Specific habitat");
            System.out.println ("4. View Animal Behavior");
            System.out.println ("5. Exit");
            System.out.println ("=============================");
            System.out.println ();

            System.out.print ("Enter your choice: ");
            choice = in.nextInt();                
       
        switch (choice)
        {
            case 1:
                int type;
                
                 System.out.println ();
                 System.out.println ("Pick type of animals");
                 System.out.println("MENU:");
                
                ArrayList <String> typeOfAnimal = new ArrayList <String>();
                typeOfAnimal.add ("1. Mammal");
                typeOfAnimal.add ("2. Primate");
                typeOfAnimal.add ("3. Bird");
                typeOfAnimal.add ("4. Fish");
                typeOfAnimal.add ("5. Reptile");
                   
                for (int i = 0; i < typeOfAnimal.size(); i++)
                {
                    System.out.println (typeOfAnimal.get(i));
                }
               
                System.out.println ();
                System.out.print ("Enter Type of Animal: ");
                type = in.nextInt();
                
                        String types;
                        String name;
                        int age;
                        String gender;
                        double weight;
                        String furColor;
                        String addAnswer;
                        
            switch (type)
                {
                    case 1:      
                        System.out.print("\n" + "Enter Mammal type: ");
                        types = in.next();
                        
                        System.out.print ("Enter " + types + " name: ");
                        name = in.next();
                        
                        System.out.print ("Enter " + name + "'s" + " age: " );
                        age = in.nextInt();
                        
                        System.out.print ("Enter " + name + "'s" + " gender: " );
                        gender = in.next();
                        
                        System.out.print ("Enter " + name + "'s" + " weight: " );
                        weight = in.nextDouble();
                        
                        System.out.print ("Enter " + name + "'s" + " Fur Color: " );
                        furColor = in.next();
                        
                        System.out.print ("Enter Habitat of " + name +" : ");
                        habitat = in.next();
                                                
                        Mammal mammal = new Mammal(types,name,age,gender, weight, furColor, habitat);
                        
                        System.out.println ("Are you sure you want to add " + name + " in the List? YES/NO ");
                        addAnswer = in.next();
                        System.out.println ();
                        
                        if (addAnswer.equalsIgnoreCase("YES"))
                        {
                            zooAnimals.add(mammal);
                            System.out.println ("Added Successfully"); 
                          
                            System.out.println ("==================================="); 
                            System.out.println ("Do you want to add again? ");
                            System.out.println ("1. YES"); 
                            System.out.println ("2. NO");
                            addAgain = in.nextInt();
                            System.out.println ("===================================");

                            if (addAgain==1)
                            {
                                anotherTransaction();
                            }
                            else if (addAgain == 2)
                            {
                                System.out.println("Exiting the Zoo Management System ");
                                System.exit(0);
                            }
                            else 
                            {
                                System.out.println("Invalid Input.");
                            }
                        }
                        
                        else if (addAnswer.equalsIgnoreCase("NO"))
                        {
                            System.out.println (name +  " is not added");
                            System.out.println ("Exiting the Zoo Management System");
                            System.exit(0);
                        }
                        
                        else 
                        {
                            System.out.println("Invalid Input");
                            System.exit(0);
                        }
                        break;
                            
                    case 2:
                            System.out.println("Ape ");
                            System.out.println("Monkey ");
                            System.out.println();
                            
                            System.out.println("Pick type of Primate");     
                            types = in.next();
                                
                        if (types.equalsIgnoreCase("APE"))
                        {
                                System.out.print ("Enter " + types + " name: ");
                                name = in.next();

                                System.out.print ("Enter " + name + "'s" + " age: " );
                                age= in.nextInt();

                                System.out.print ("Enter " + name + "'s" + " gender: " );
                                gender = in.next();

                                System.out.print ("Enter " + name + "'s" + " weight: " );
                                weight = in.nextDouble();

                                System.out.print ("Enter " + name + "'s" + " Skin Color: " );
                                furColor = in.next(); 
                                
                                System.out.print("Enter Habitat of " + name + ":");
                                habitat = in.next();
   
                                Ape ape = new Ape (types,name,age,gender,weight,furColor,habitat);

                                System.out.println ("Are you sure you want to add " + name + " in the List? YES/NO ");
                                addAnswer = in.next();
                                System.out.println ();

                            if (addAnswer.equalsIgnoreCase("YES"))
                            {
                                zooAnimals.add (ape );
                                System.out.println ("Added Successfully");
                                
                                System.out.println ("==================================="); 
                                System.out.println ("Do you want to add again? ");
                                System.out.println ("1. YES"); 
                                System.out.println ("2. NO");
                                addAgain = in.nextInt();
                                System.out.println ("===================================");

                            if (addAgain==1)
                            {
                                anotherTransaction();
                            }
                            else if (addAgain == 2)
                            {
                                System.out.println("Exiting the Zoo Management System ");
                                System.exit(0);
                            }
                            else 
                            {
                                System.out.println("Invalid Input.");
                            }
                            }

                            else if (addAnswer.equalsIgnoreCase("NO"))
                            {
                                 System.out.println (name +  " is not Added");
                                 System.out.println ("Exiting the Zoo Management System");
                                 System.exit(0);
                            }

                            else 
                            {
                                System.out.println ("Invalid Input");
                                System.exit(0);
                            }
                        }
                        else if (types.equalsIgnoreCase("MONKEY"))
                        {
                                System.out.print ("Enter " + types + " name: ");
                                name = in.next();

                                System.out.print ("Enter " + name + "'s" + " age: " );
                                age= in.nextInt();

                                System.out.print ("Enter " + name + "'s" + " gender: " );
                                gender = in.next();

                                System.out.print ("Enter " + name + "'s" + " weight: " );
                                weight = in.nextDouble();

                                System.out.print ("Enter " + name + "'s" + " Skin Color: " );
                                furColor = in.next(); 
                                
                                System.out.print("Enter Habitat of " + name + ":");
                                habitat = in.next();

                                Monkey monkey = new Monkey (types,name,age,gender,weight,furColor,habitat);
                                                                
                                System.out.println ("Are you sure you want to add " + name + " in the List? YES/NO ");
                                addAnswer = in.next();
                                System.out.println ();

                            if (addAnswer.equalsIgnoreCase("YES"))
                            {
                                zooAnimals.add (monkey);
                                System.out.println ("Added Successfully");
                                
                                System.out.println ("==================================="); 
                                System.out.println ("Do you want to add again? ");
                                System.out.println ("1. YES"); 
                                System.out.println ("2. NO");
                                addAgain = in.nextInt();
                                System.out.println ("===================================");

                            if (addAgain==1)
                            {
                                anotherTransaction();
                            }
                            else if (addAgain == 2)
                            {
                                System.out.println("Exiting the Zoo Management System ");
                                System.exit(0);
                            }
                            else 
                            {
                                System.out.println("Invalid Input.");
                            }
                            }

                            else if (addAnswer.equalsIgnoreCase("NO"))
                            {
                                 System.out.println (name +  " is not Added");
                                 System.out.println ("Exiting the Zoo Management System");
                                 System.exit(0);
                            }

                            else 
                            {
                                System.out.println ("Invalid Input");
                                System.exit(0);
                            }

                        }
                            break;     
                    case 3:
                            double wingSpan;
                            String featherColor;
                            
                            System.out.print("Enter Bird type: ");
                            types = in.next();
                            
                            System.out.print ("Enter " + types + " name: ");
                            name = in.next();
                        
                            System.out.print ("Enter " + name+ "'s" + " age: " );
                            age = in.nextInt();
                            
                            System.out.print ("Enter " + name + "'s" + " gender: " );
                            gender = in.next();
                        
                            System.out.print ("Enter " + name + "'s" + " weight: " );
                            weight = in.nextDouble();
                        
                            System.out.print ("Enter " + name + "'s" + " wing span: " );
                            wingSpan = in.nextDouble();
                            
                            System.out.print ("Enter " + types + "'s" + " feather color: ");
                            featherColor = in.next();
                            
                            System.out.print("Enter Habitat of " + name + ":");
                            habitat = in.next();
                           
                            Bird bird = new Bird (types,name,age,gender,weight,wingSpan,featherColor,habitat);
                            
                            System.out.println ("Are you sure you want to add " + name + " in the List? YES/NO ");
                            addAnswer = in.next();
                            System.out.println ();
                            
                            if (addAnswer.equalsIgnoreCase("YES"))
                            {
                                zooAnimals.add (bird);
                                System.out.println ("Added Successfully");
                                
                                System.out.println ("==================================="); 
                                System.out.println ("Do you want to add again? ");
                                System.out.println ("1. YES"); 
                                System.out.println ("2. NO");
                                addAgain = in.nextInt();
                                System.out.println ("===================================");

                            if (addAgain==1)
                            {
                                anotherTransaction();
                            }
                            else if (addAgain == 2)
                            {
                                System.out.println("Exiting the Zoo Management System ");
                                System.exit(0);
                            }
                            else 
                            {
                                System.out.println("Invalid Input.");
                            }
                            }

                            else if (addAnswer.equalsIgnoreCase("NO"))
                            {
                                 System.out.println (name +  " is not Added");
                                 System.out.println ("Exiting the Zoo Management System");
                                 System.exit(0);
                            }

                            else 
                            {
                                System.out.println ("Invalid Input");
                                System.exit(0);
                            }
                            break;                         
                    case 4:
                           
                            double lenght;        
                            double bodyDepth;   
                            
                            System.out.print("Enter Fish type: ");
                            types = in.next();
                            
                            System.out.print ("Enter " + types + " name: ");
                            name = in.next();
                            
                            System.out.print ("Enter " + name + "'s" + " age: " );
                            age = in.nextInt();
                            
                            System.out.print ("Enter " + name + "'s" + " gender: " );
                            gender = in.next();
                        
                            System.out.print ("Enter " + name + "'s" + " weight: " );
                            weight = in.nextDouble();
                            
                            System.out.print ("Enter " + name + "'s" + " standard length: " );
                            lenght = in.nextDouble();
                            
                            System.out.print ("Enter " + name + "'s" + " body depth: " );
                            bodyDepth = in.nextDouble();
                            
                            System.out.print("Enter Habitat of " + name +":");
                            habitat = in.next();
                            
                            Fish fish = new Fish(types,name,age,gender, weight, lenght, bodyDepth, habitat);
                            
                            System.out.println ("Are you sure you want to add " + name + " in the List? YES/NO ");
                            addAnswer = in.next();
                            System.out.println ();
                            
                            if (addAnswer.equalsIgnoreCase("YES"))
                            {
                                zooAnimals.add (fish);
                                System.out.println ("Added Successfully");
                                System.out.println ("==================================="); 
                                System.out.println ("Do you want to add again? ");
                                System.out.println ("1. YES"); 
                                System.out.println ("2. NO");
                                addAgain = in.nextInt();
                                System.out.println ("===================================");

                            if (addAgain==1)
                            {
                                anotherTransaction();
                            }
                            else if (addAgain == 2)
                            {
                                System.out.println("Exiting the Zoo Management System ");
                                System.exit(0);
                            }
                            else 
                            {
                                System.out.println("Invalid Input.");
                            }
                            }

                            else if (addAnswer.equalsIgnoreCase("NO"))
                            {
                                 System.out.println (name +  " is not Added");
                                 System.out.println ("Exiting the Zoo Management System");
                                 System.exit(0);
                            }
                            
                            else 
                            {
                                System.out.println ("Invalid Input");
                                System.exit(0);
                            }
                            
                            break;
                    case 5:
                            String skinColor;
                            
                            System.out.print("Enter Reptile type: ");
                            types= in.next();
                            
                            System.out.print ("Enter " + types + " name: ");
                            name = in.next();
                            
                            System.out.print ("Enter " + name + "'s" + " age: " );
                            age = in.nextInt();
                            
                            System.out.print ("Enter " + name + "'s" + " gender: " );
                            gender = in.next();
                            
                            System.out.print ("Enter " + name + "'s" + " weight: " );
                            weight = in.nextDouble();
                            
                            System.out.print ("Enter " + name + "'s" + " skin color: " );
                            skinColor = in.next();
                            
                            System.out.print("Enter Habitat of " + name + ":");
                            habitat = in.next();
                            
                            Reptile reptile = new Reptile (types,name,age,gender, weight, skinColor, habitat);
                      
                            System.out.println ("Are you sure you want to add " + name + " in the List? YES/NO ");
                            addAnswer= in.next();
                            System.out.println ();
                            
                            if (addAnswer.equalsIgnoreCase("YES"))
                            {
                                zooAnimals.add (reptile );
                                System.out.println ("Added Successfully");
                                System.out.println ("==================================="); 
                                System.out.println ("Do you want to add again? ");
                                System.out.println ("1. YES"); 
                                System.out.println ("2. NO");
                                addAgain = in.nextInt();
                                System.out.println ("===================================");

                            if (addAgain==1)
                            {
                                anotherTransaction();
                            }
                            else if (addAgain == 2)
                            {
                                System.out.println("Exiting the Zoo Management System ");
                                System.exit(0);
                            }
                            else 
                            {
                                System.out.println("Invalid Input.");
                            }
                            }

                            else if (addAnswer.equalsIgnoreCase("NO"))
                            {
                                 System.out.println (name +  " is not Added");
                                 System.out.println ("Exiting the Zoo Management System");
                                 System.exit(0);
                            }
                            
                            else 
                            {
                                System.out.println ("Invalid Input");
                                System.exit(0);
                            }
                           
                            break;
      
            }   
                break;
            case 2:
                System.out.println("====================");
                System.out.println("Animal in the Zoo");
              
                for (Animal animal : zooAnimals)
                {                    
                    System.out.println("Type of Animal:" + animal.types + ", Name: " + animal.name + ", Age: " + animal.age + ", Weight:" + animal.weight + ", Habitat: " + animal.habitat);
                }
                            
                            System.out.println ("==================================="); 
                            System.out.println ("Do you want to another transaction? ");
                            System.out.println ("1. YES"); 
                            System.out.println ("2. NO");
                            addAgain = in.nextInt();
                            System.out.println ("===================================");

                            if (addAgain==1)
                            {
                                anotherTransaction();
                            }
                            else if (addAgain == 2)
                            {
                                System.out.println("Exiting the Zoo Management System ");
                                System.exit(0);
                            }
                            else 
                            {
                                System.out.println("Invalid Input.");
                            }
                break;
            case 3:
                for (Animal animal : zooAnimals)
                {                    
                    System.out.println("Type of Animal:" + animal.types + " Lives in " + animal.habitat );
                }
            
                            System.out.println ("==================================="); 
                            System.out.println ("Do you want to another transaction? ");
                            System.out.println ("1. YES"); 
                            System.out.println ("2. NO");
                            addAgain = in.nextInt();
                            System.out.println ("===================================");

                            if (addAgain==1)
                            {
                                anotherTransaction();
                            }
                            else if (addAgain == 2)
                            {
                                System.out.println("Exiting the Zoo Management System ");
                                System.exit(0);
                            }
                            else 
                            {
                                System.out.println("Invalid Input.");
                            }
               break;
              
            case 4:
                for (Animal animal : zooAnimals)
                {     
                    System.out.println("Type of Animal:" + animal.types + "\n");
                    animal.makeSound();
                    animal.eat();
                    animal.sleep();
                    
                    if(animal instanceof Climber)
                    {
                     ((Climber)animal).climb();
                    }
                    
                    if(animal instanceof Flyable)
                    {
                     ((Flyable)animal).fly();
                    }
                    
                    if(animal instanceof Walking)
                    {
                     ((Walking)animal).walk();
                    }
                    
                    if(animal instanceof Swimmable)
                    {
                     ((Swimmable)animal).swim();
                    }
                }
                
                            System.out.println ("==================================="); 
                            System.out.println ("Do you want to another transaction? ");
                            System.out.println ("1. YES"); 
                            System.out.println ("2. NO");
                            addAgain = in.nextInt();
                            System.out.println ("===================================");

                            if (addAgain==1)
                            {
                                anotherTransaction();
                            }
                            else if (addAgain == 2)
                            {
                                System.out.println("Exiting the Zoo Management System ");
                                System.exit(0);
                            }
                            else 
                            {
                                System.out.println("Invalid Input.");
                            }
                break;
            case 5:
               System.out.println ("===================================");
               System.out.println("Exiting the Zoo Management System "); 
               System.out.println ("===================================");
               System.exit(0);
               break;
            default:
                    System.out.println ("===================================");
                    System.out.println("Invalid Choice. Please Try Again ");
                    System.out.println ("===================================");
                    System.exit(0); 
        }
           
        }  
  
        else if (transac == 2)
        { 
            System.out.println ("===================================");
            System.out.println("Exiting the Zoo Management System");
            System.out.println ("===================================");
            System.exit(0); 
        }
       
        else if (transac != 1 | transac != 2)
        {
            System.out.println ("===================================");
            System.out.println("Invalid Input");
            System.out.println ("===================================");
            System.exit(0); 
        }
        
        else
        {
            System.out.println ("===================================");
            System.out.println("Invalid Input");
            System.out.println ("===================================");
            System.exit(0);       
        }    
    } 
       
 }