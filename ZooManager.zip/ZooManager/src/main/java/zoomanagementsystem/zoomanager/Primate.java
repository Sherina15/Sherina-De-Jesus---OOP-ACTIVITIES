package zoomanagementsystem.zoomanager;

public class Primate extends Mammal implements Climber
{
   
    public Primate (String types,String name, int age, String gender, double weight, String furColor, String habitat)
    {
        super(types,name,age,gender,weight,furColor,habitat);
    }
    
    @Override
    void makeSound()
    {
    
    }
    
    @Override
    void sleep()
    {
        
    }
    
    @Override
    void eat()
    {
        
    }
    
    @Override
    public void climb() 
    {
       
    }
    
}
