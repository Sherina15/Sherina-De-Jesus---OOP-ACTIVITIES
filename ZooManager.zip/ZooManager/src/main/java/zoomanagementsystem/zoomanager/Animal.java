package zoomanagementsystem.zoomanager;

public abstract class Animal 
{
     String types;
     String name;
     int age;
     String gender;
     double weight;
     String habitat;

    abstract void makeSound();
    abstract void sleep();
    abstract void eat();
    
    public Animal (String types, String name,int age, String gender, double weight, String habitat)
    {
        this.types = types;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.weight = weight;     
        this.habitat = habitat;
    }
    
   public String getTypes()
    {
        return types;
    }
   
    public String getName ()
    {
        return name;
    }
    
    public int getAge()
    {
        return age;
    }
    
    public String getGender()
    {
        return gender;
    }
    
    public double getWeight()
    {
        return weight;
    }   
    public String gethabitat()
    {
        return habitat;
    }
    
}
