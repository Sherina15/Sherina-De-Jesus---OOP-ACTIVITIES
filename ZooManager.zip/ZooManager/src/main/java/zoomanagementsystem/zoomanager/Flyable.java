package zoomanagementsystem.zoomanager;

public interface Flyable 
{
    void fly();    
}
