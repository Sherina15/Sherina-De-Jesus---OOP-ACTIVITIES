package zoomanagementsystem.zoomanager;

public class Reptile extends Animal implements Walking, Swimmable 
{
    String skinColor;
    
    public Reptile(String types, String name, int age,String gender , double weight, String skinColor, String habitat)
    {
        super (types,name,age,gender, weight, habitat);
        this.skinColor = skinColor;
    }

    @Override
    void makeSound() 
    {
     System.out.println( types + " can make sound");
    }

    @Override
    void sleep() 
    {
     System.out.println( types + " is sleepy");   
    }

    @Override
    void eat() 
    {
     System.out.println( types + " is eating");   
    }

    @Override
    public void walk() 
    {
      System.out.println( types + " is walking");  
    }

    @Override
    public void swim() 
    {
     System.out.println( types + " Swum in the pond");   
    }
}
