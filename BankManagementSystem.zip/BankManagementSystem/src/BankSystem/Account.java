package BankSystem;

import javax.swing.JOptionPane;

public class Account extends javax.swing.JFrame {
 
    private double amountBalance = 46000.00;
    
    public Account() {
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel = new javax.swing.JPanel();
        topPanel = new javax.swing.JPanel();
        cloverLabel = new javax.swing.JLabel();
        cloverBankLabel = new javax.swing.JLabel();
        greetingLabel = new javax.swing.JLabel();
        rightPanel = new javax.swing.JPanel();
        viewAccountButton = new javax.swing.JButton();
        withdrawButton = new javax.swing.JButton();
        depositButton = new javax.swing.JButton();
        transferButton = new javax.swing.JButton();
        exitButton = new javax.swing.JButton();
        tabbedPane = new javax.swing.JTabbedPane();
        viewAccount = new javax.swing.JPanel();
        profileLabel = new javax.swing.JLabel();
        name = new javax.swing.JLabel();
        accountNumber = new javax.swing.JLabel();
        accountBalancePanel = new javax.swing.JPanel();
        accountBalanceLabel = new javax.swing.JLabel();
        accountBalance = new javax.swing.JLabel();
        withdraw = new javax.swing.JPanel();
        withdrawLabel = new javax.swing.JLabel();
        pinNumberLabel = new javax.swing.JLabel();
        pinNumberField = new javax.swing.JPasswordField();
        amountLabel = new javax.swing.JLabel();
        amountToWithdrawField = new javax.swing.JTextField();
        withdrawWarningLabel = new javax.swing.JLabel();
        withdrawWarningMessage = new javax.swing.JLabel();
        withdrawWarningMessage2 = new javax.swing.JLabel();
        withdrawMoneyButton = new javax.swing.JButton();
        deposit = new javax.swing.JPanel();
        depositLabel = new javax.swing.JLabel();
        amountToDepositLabel = new javax.swing.JLabel();
        amountToDepositField = new javax.swing.JTextField();
        depositMoneyButton = new javax.swing.JButton();
        depositWarningLabel = new javax.swing.JLabel();
        depositWarningMessage = new javax.swing.JLabel();
        depositWarningMessage2 = new javax.swing.JLabel();
        transfer = new javax.swing.JPanel();
        transferLabel = new javax.swing.JLabel();
        accountNumberTransferLabel = new javax.swing.JLabel();
        transferAccountNumberField = new javax.swing.JTextField();
        transferAmountLabel = new javax.swing.JLabel();
        tranferAmountField = new javax.swing.JTextField();
        tranferMoneyButton = new javax.swing.JButton();
        transferWarningLabel = new javax.swing.JLabel();
        transferWarningMessage = new javax.swing.JLabel();
        transferWarningMessage2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("BANK MENU");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        panel.setBackground(new java.awt.Color(204, 204, 204));
        panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        topPanel.setBackground(new java.awt.Color(0, 0, 0));

        cloverLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/CloverIcon.jpg"))); // NOI18N

        cloverBankLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        cloverBankLabel.setForeground(new java.awt.Color(255, 255, 255));
        cloverBankLabel.setText("CLOVER BANK");

        greetingLabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        greetingLabel.setForeground(new java.awt.Color(204, 204, 204));
        greetingLabel.setText("Hi! Welcome Sherina");

        javax.swing.GroupLayout topPanelLayout = new javax.swing.GroupLayout(topPanel);
        topPanel.setLayout(topPanelLayout);
        topPanelLayout.setHorizontalGroup(
            topPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(topPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cloverLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(topPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cloverBankLabel)
                    .addComponent(greetingLabel))
                .addContainerGap(404, Short.MAX_VALUE))
        );
        topPanelLayout.setVerticalGroup(
            topPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(topPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(topPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(cloverLabel)
                    .addGroup(topPanelLayout.createSequentialGroup()
                        .addComponent(cloverBankLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(greetingLabel)
                        .addGap(12, 12, 12)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panel.add(topPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 630, 110));

        rightPanel.setBackground(new java.awt.Color(0, 0, 0));

        viewAccountButton.setBackground(new java.awt.Color(0, 0, 0));
        viewAccountButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        viewAccountButton.setForeground(new java.awt.Color(255, 255, 255));
        viewAccountButton.setText("View Account");
        viewAccountButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewAccountButtonActionPerformed(evt);
            }
        });

        withdrawButton.setBackground(new java.awt.Color(0, 0, 0));
        withdrawButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        withdrawButton.setForeground(new java.awt.Color(255, 255, 255));
        withdrawButton.setText("Withdraw");
        withdrawButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                withdrawButtonActionPerformed(evt);
            }
        });

        depositButton.setBackground(new java.awt.Color(0, 0, 0));
        depositButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        depositButton.setForeground(new java.awt.Color(255, 255, 255));
        depositButton.setText("Deposit");
        depositButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                depositButtonActionPerformed(evt);
            }
        });

        transferButton.setBackground(new java.awt.Color(0, 0, 0));
        transferButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        transferButton.setForeground(new java.awt.Color(255, 255, 255));
        transferButton.setText("Transfer ");
        transferButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                transferButtonActionPerformed(evt);
            }
        });

        exitButton.setBackground(new java.awt.Color(0, 0, 0));
        exitButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        exitButton.setForeground(new java.awt.Color(255, 255, 255));
        exitButton.setText("Exit");
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout rightPanelLayout = new javax.swing.GroupLayout(rightPanel);
        rightPanel.setLayout(rightPanelLayout);
        rightPanelLayout.setHorizontalGroup(
            rightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(viewAccountButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 173, Short.MAX_VALUE)
            .addComponent(withdrawButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(depositButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(transferButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(exitButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        rightPanelLayout.setVerticalGroup(
            rightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(rightPanelLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(viewAccountButton, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(withdrawButton, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(depositButton, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(transferButton, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(exitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(10, Short.MAX_VALUE))
        );

        panel.add(rightPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, -1, 360));

        tabbedPane.setBackground(new java.awt.Color(255, 255, 255));

        viewAccount.setBackground(new java.awt.Color(255, 255, 255));

        profileLabel.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        profileLabel.setText("PROFILE");

        name.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        name.setText("Name: Sherina De Jesus");

        accountNumber.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        accountNumber.setText("Account Number: 102938475632");

        accountBalancePanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));

        accountBalanceLabel.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        accountBalanceLabel.setText("Account Balance: PHP");

        accountBalance.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N

        javax.swing.GroupLayout accountBalancePanelLayout = new javax.swing.GroupLayout(accountBalancePanel);
        accountBalancePanel.setLayout(accountBalancePanelLayout);
        accountBalancePanelLayout.setHorizontalGroup(
            accountBalancePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(accountBalancePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(accountBalanceLabel)
                .addGap(18, 18, 18)
                .addComponent(accountBalance, javax.swing.GroupLayout.DEFAULT_SIZE, 155, Short.MAX_VALUE)
                .addContainerGap())
        );
        accountBalancePanelLayout.setVerticalGroup(
            accountBalancePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(accountBalancePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(accountBalancePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(accountBalancePanelLayout.createSequentialGroup()
                        .addComponent(accountBalanceLabel)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(accountBalance, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout viewAccountLayout = new javax.swing.GroupLayout(viewAccount);
        viewAccount.setLayout(viewAccountLayout);
        viewAccountLayout.setHorizontalGroup(
            viewAccountLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(viewAccountLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(viewAccountLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(profileLabel)
                    .addComponent(name)
                    .addComponent(accountNumber)
                    .addComponent(accountBalancePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        viewAccountLayout.setVerticalGroup(
            viewAccountLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(viewAccountLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(profileLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(name)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(accountNumber)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(accountBalancePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(177, Short.MAX_VALUE))
        );

        tabbedPane.addTab("View Account", viewAccount);

        withdraw.setBackground(new java.awt.Color(255, 255, 255));

        withdrawLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        withdrawLabel.setText("WITHDRAWAL");

        pinNumberLabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        pinNumberLabel.setText("Enter PIN");

        pinNumberField.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        pinNumberField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                pinNumberFieldKeyTyped(evt);
            }
        });

        amountLabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        amountLabel.setText("Enter Amount PHP");

        amountToWithdrawField.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        amountToWithdrawField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                amountToWithdrawFieldKeyTyped(evt);
            }
        });

        withdrawWarningLabel.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        withdrawWarningLabel.setForeground(new java.awt.Color(255, 51, 0));
        withdrawWarningLabel.setText("WARNING: ");

        withdrawWarningMessage.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        withdrawWarningMessage.setText("Do not input decimal format or include  ");

        withdrawWarningMessage2.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        withdrawWarningMessage2.setText("( , ) ex. (100.00) or (1,000)");

        withdrawMoneyButton.setBackground(new java.awt.Color(0, 0, 0));
        withdrawMoneyButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        withdrawMoneyButton.setForeground(new java.awt.Color(255, 255, 255));
        withdrawMoneyButton.setText("Withdraw");
        withdrawMoneyButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                withdrawMoneyButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout withdrawLayout = new javax.swing.GroupLayout(withdraw);
        withdraw.setLayout(withdrawLayout);
        withdrawLayout.setHorizontalGroup(
            withdrawLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(withdrawLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(withdrawLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(withdrawLabel)
                    .addGroup(withdrawLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(withdrawLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(withdrawWarningLabel)
                            .addComponent(amountLabel)
                            .addComponent(pinNumberLabel))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(withdrawLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(amountToWithdrawField, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(withdrawLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(withdrawMoneyButton, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(pinNumberField, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(withdrawWarningMessage)
                            .addComponent(withdrawWarningMessage2, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(76, Short.MAX_VALUE))
        );
        withdrawLayout.setVerticalGroup(
            withdrawLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(withdrawLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(withdrawLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(withdrawLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(amountLabel)
                    .addComponent(amountToWithdrawField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(withdrawLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(withdrawWarningLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(withdrawWarningMessage))
                .addGap(2, 2, 2)
                .addComponent(withdrawWarningMessage2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(withdrawLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(pinNumberLabel)
                    .addComponent(pinNumberField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(withdrawMoneyButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(122, Short.MAX_VALUE))
        );

        tabbedPane.addTab("Withdraw", withdraw);

        deposit.setBackground(new java.awt.Color(255, 255, 255));

        depositLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        depositLabel.setText("DEPOSIT ");

        amountToDepositLabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        amountToDepositLabel.setText("Enter Amount PHP");

        amountToDepositField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        amountToDepositField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                amountToDepositFieldKeyTyped(evt);
            }
        });

        depositMoneyButton.setBackground(new java.awt.Color(0, 0, 0));
        depositMoneyButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        depositMoneyButton.setForeground(new java.awt.Color(255, 255, 255));
        depositMoneyButton.setText("Deposit");
        depositMoneyButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                depositMoneyButtonActionPerformed(evt);
            }
        });

        depositWarningLabel.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        depositWarningLabel.setForeground(new java.awt.Color(255, 0, 0));
        depositWarningLabel.setText("WARNING");

        depositWarningMessage.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        depositWarningMessage.setText("Do not input decimal format or include ( , ) ");

        depositWarningMessage2.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        depositWarningMessage2.setText("ex. (100.00) or (1,000)");

        javax.swing.GroupLayout depositLayout = new javax.swing.GroupLayout(deposit);
        deposit.setLayout(depositLayout);
        depositLayout.setHorizontalGroup(
            depositLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(depositLayout.createSequentialGroup()
                .addGroup(depositLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(depositLayout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(depositLabel))
                    .addGroup(depositLayout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addGroup(depositLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(depositLayout.createSequentialGroup()
                                .addComponent(amountToDepositLabel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(amountToDepositField, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(depositLayout.createSequentialGroup()
                                .addGap(67, 67, 67)
                                .addComponent(depositWarningLabel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(depositLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(depositWarningMessage2)
                                    .addComponent(depositWarningMessage))))))
                .addContainerGap(28, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, depositLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(depositMoneyButton, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(114, 114, 114))
        );
        depositLayout.setVerticalGroup(
            depositLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(depositLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(depositLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(depositLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(amountToDepositLabel)
                    .addComponent(amountToDepositField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(depositLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(depositWarningLabel)
                    .addComponent(depositWarningMessage))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(depositWarningMessage2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(depositMoneyButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(162, Short.MAX_VALUE))
        );

        tabbedPane.addTab("Deposit", deposit);

        transfer.setBackground(new java.awt.Color(255, 255, 255));

        transferLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        transferLabel.setText("TRANSFER");

        accountNumberTransferLabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        accountNumberTransferLabel.setText("Enter Account Number");

        transferAccountNumberField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        transferAccountNumberField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                transferAccountNumberFieldKeyTyped(evt);
            }
        });

        transferAmountLabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        transferAmountLabel.setText("Enter Amount PHP");

        tranferAmountField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        tranferAmountField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tranferAmountFieldKeyTyped(evt);
            }
        });

        tranferMoneyButton.setBackground(new java.awt.Color(0, 0, 0));
        tranferMoneyButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        tranferMoneyButton.setForeground(new java.awt.Color(255, 255, 255));
        tranferMoneyButton.setText("Transfer");
        tranferMoneyButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tranferMoneyButtonActionPerformed(evt);
            }
        });

        transferWarningLabel.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        transferWarningLabel.setForeground(new java.awt.Color(255, 0, 0));
        transferWarningLabel.setText("WARNING");

        transferWarningMessage.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        transferWarningMessage.setText("Do not input decimal format or include  ");

        transferWarningMessage2.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        transferWarningMessage2.setText("( , ) ex. (100.00) or (1,000)");

        javax.swing.GroupLayout transferLayout = new javax.swing.GroupLayout(transfer);
        transfer.setLayout(transferLayout);
        transferLayout.setHorizontalGroup(
            transferLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(transferLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(transferLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(transferLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(transferLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(transferAmountLabel)
                            .addComponent(accountNumberTransferLabel)
                            .addComponent(transferWarningLabel))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(transferLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(transferAccountNumberField, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tranferAmountField, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(transferWarningMessage)
                            .addGroup(transferLayout.createSequentialGroup()
                                .addGap(41, 41, 41)
                                .addComponent(tranferMoneyButton, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(transferWarningMessage2, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(transferLabel))
                .addContainerGap(44, Short.MAX_VALUE))
        );
        transferLayout.setVerticalGroup(
            transferLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(transferLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(transferLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(transferLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(transferAccountNumberField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(accountNumberTransferLabel))
                .addGap(18, 18, 18)
                .addGroup(transferLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(transferAmountLabel)
                    .addComponent(tranferAmountField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(transferLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(transferWarningLabel)
                    .addComponent(transferWarningMessage))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(transferWarningMessage2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tranferMoneyButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(110, Short.MAX_VALUE))
        );

        tabbedPane.addTab("Transfer", transfer);

        panel.add(tabbedPane, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 80, 460, 360));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel, javax.swing.GroupLayout.PREFERRED_SIZE, 630, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        getAccessibleContext().setAccessibleDescription("");

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void viewAccountButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewAccountButtonActionPerformed
        tabbedPane.setSelectedIndex(0);
    }//GEN-LAST:event_viewAccountButtonActionPerformed

    private void withdrawButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_withdrawButtonActionPerformed
        tabbedPane.setSelectedIndex(1);
    }//GEN-LAST:event_withdrawButtonActionPerformed

    private void depositButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_depositButtonActionPerformed
        tabbedPane.setSelectedIndex(2);
    }//GEN-LAST:event_depositButtonActionPerformed

    private void transferButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_transferButtonActionPerformed
        tabbedPane.setSelectedIndex(3);
    }//GEN-LAST:event_transferButtonActionPerformed

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        int choice = JOptionPane.showConfirmDialog(null, 
                  "Are you sure you want to exit",
                    "Exit",JOptionPane.YES_NO_OPTION );
        
        if (choice == JOptionPane.YES_OPTION)
        {
           JOptionPane.showMessageDialog(null, "Thank you, Exiting Clover Bank System",
                                        "EXIT",JOptionPane.INFORMATION_MESSAGE);
           System.exit(0); 
        }   
    }//GEN-LAST:event_exitButtonActionPerformed
    
    private void updateBalance()
    {   
        String strAmountBalance = Double.toString(amountBalance);
        accountBalance.setText(strAmountBalance); 
    } 
    
    private void amountToWithdrawFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_amountToWithdrawFieldKeyTyped
        char c = evt.getKeyChar();
        
        if (Character.isAlphabetic(c))
        {
            amountToWithdrawField.setEditable(false);
            JOptionPane.showMessageDialog(null, "Input Numerical Values to Withdraw", "WARNING",JOptionPane.WARNING_MESSAGE);     
        }
        else
        {
            amountToWithdrawField.setEditable(true);    
        }
    }//GEN-LAST:event_amountToWithdrawFieldKeyTyped

    private void withdrawMoneyButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_withdrawMoneyButtonActionPerformed
        if (pinNumberField.getText().equals("") && amountToWithdrawField.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "Fill out Pin Number and Amount to Withdraw","ERROR",JOptionPane.ERROR_MESSAGE);
            amountToWithdrawField.setText("");
            pinNumberField.setText("");
        }
        else if (pinNumberField.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "Fill out Pin Number","ERROR",JOptionPane.ERROR_MESSAGE);
            amountToWithdrawField.setText("");
            pinNumberField.setText("");
        }
        else if (amountToWithdrawField.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "Input Amount","ERROR",JOptionPane.ERROR_MESSAGE);
            amountToWithdrawField.setText("");
            pinNumberField.setText("");
        }
        else if (pinNumberField.getText().equals("125689"))
        { 
            int choice = JOptionPane.showConfirmDialog(null, 
                                                   "Are you sure you want to withdraw PHP "   
                                                   + amountToWithdrawField.getText() , 
                                                   "Withdraw", 
                                                   JOptionPane.YES_NO_OPTION);
           
            double amountToWithdraw = Double.parseDouble( amountToWithdrawField.getText());
            
            if (choice == JOptionPane.YES_OPTION)
            {
                if (amountToWithdraw > amountBalance)
                {
                    JOptionPane.showMessageDialog(null, "Insufficient Balance","ERROR",JOptionPane.ERROR_MESSAGE);
                    amountToWithdrawField.setText("");
                    pinNumberField.setText("");
                } 
                
                else if (amountBalance - amountToWithdraw < 500)
                {
                    updateBalance();
                    JOptionPane.showMessageDialog(null, "Withdrawal Amount Exceeds the Minimum Balance Requirement", 
                                                  "WARNING",JOptionPane.WARNING_MESSAGE);
                    amountToWithdrawField.setText("");
                    pinNumberField.setText("");
                }
                else if (amountToWithdraw <= amountBalance && amountToWithdraw > 199 )
                {
                    amountBalance -= amountToWithdraw;
                    updateBalance();

                    JOptionPane.showMessageDialog(null, "Withdraw Successfully",
                                                  "Transaction Success",JOptionPane.INFORMATION_MESSAGE);
                    amountToWithdrawField.setText("");
                    pinNumberField.setText("");
                }
                else if (amountToWithdraw < 200)
                {
                    JOptionPane.showMessageDialog(null, "Minimum is PHP 200.00 to Withdraw, Please Try Again.",
                                                  "WARNING",JOptionPane.WARNING_MESSAGE);
                    amountToWithdrawField.setText("");
                    pinNumberField.setText("");
                }                 
            }
            else if (choice == JOptionPane.NO_OPTION )
            {
                JOptionPane.showMessageDialog(null, "Withdraw Cancelled", "CANCELLED",JOptionPane.ERROR_MESSAGE);
                amountToWithdrawField.setText("");
                pinNumberField.setText("");
            }   
        }
        else 
        {
            JOptionPane.showMessageDialog(null, "Incorrect PIN ", "ERROR",JOptionPane.ERROR_MESSAGE);
            amountToWithdrawField.setText("");
            pinNumberField.setText("");
        }
    }//GEN-LAST:event_withdrawMoneyButtonActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        String strAmountBalance = Double.toString(amountBalance);
        accountBalance.setText(strAmountBalance); 
    }//GEN-LAST:event_formWindowOpened

    private void pinNumberFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pinNumberFieldKeyTyped
        char c = evt.getKeyChar();
        
        if (Character.isAlphabetic(c))
        {
            pinNumberField.setEditable(false);
            JOptionPane.showMessageDialog(null, "Pin Number only Contain Numerical Values", "WARNING",JOptionPane.WARNING_MESSAGE);
        }
        else
        {
            pinNumberField.setEditable(true);    
        }
         
    }//GEN-LAST:event_pinNumberFieldKeyTyped

    private void depositMoneyButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_depositMoneyButtonActionPerformed
        if (amountToDepositField.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "Input Amount in the Field to Deposit","WARNING",JOptionPane.WARNING_MESSAGE);
            amountToDepositField.setText("");
        }
        else
        { 
           int choice = JOptionPane.showConfirmDialog(null, 
                                                   "Are you sure you want to deposit PHP "   
                                                   + amountToDepositField.getText() , 
                                                   "Deposit", 
                                                   JOptionPane.YES_NO_OPTION); 
           
           double amountToDeposit = Double.parseDouble( amountToDepositField.getText());
           
            if (choice == JOptionPane.YES_OPTION)
            {
                if (amountToDeposit > 0)
                {
                    amountBalance += amountToDeposit;
                    updateBalance();
                    
                    JOptionPane.showMessageDialog(null, "Deposit Successfully",
                                                  "Transaction Success",JOptionPane.INFORMATION_MESSAGE);
                    amountToDepositField.setText("");    
                } 
                else
                {
                    JOptionPane.showMessageDialog(null, "Invalid Amount",
                                                 "ERROR",JOptionPane.ERROR_MESSAGE);
                    amountToDepositField.setText("");
                }
            }
            else if (choice == JOptionPane.NO_OPTION )
            {
                JOptionPane.showMessageDialog(null, "Deposit Cancelled", "CANCELLED",JOptionPane.ERROR_MESSAGE);
                amountToDepositField.setText("");
            }  
        }      
    }//GEN-LAST:event_depositMoneyButtonActionPerformed

    private void amountToDepositFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_amountToDepositFieldKeyTyped
        char c = evt.getKeyChar();
        
        if (Character.isAlphabetic(c))
        {
            amountToDepositField.setEditable(false);
            JOptionPane.showMessageDialog(null, "Input Amount in Numerical Values ", "WARNING",JOptionPane.WARNING_MESSAGE);
        }
        else
        {
            amountToDepositField.setEditable(true);    
        }
    }//GEN-LAST:event_amountToDepositFieldKeyTyped

    private void transferAccountNumberFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_transferAccountNumberFieldKeyTyped
        char c = evt.getKeyChar();
        
        if (Character.isAlphabetic(c))
        {
            transferAccountNumberField.setEditable(false);
            JOptionPane.showMessageDialog(null, "Account Number is Written in Numerical Values", "WARNING",JOptionPane.WARNING_MESSAGE);
        }
        else
        {
            transferAccountNumberField.setEditable(true);    
        }  
    }//GEN-LAST:event_transferAccountNumberFieldKeyTyped

    private void tranferAmountFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tranferAmountFieldKeyTyped
        char c = evt.getKeyChar();
        
        if (Character.isAlphabetic(c))
        {
            tranferAmountField.setEditable(false);
            JOptionPane.showMessageDialog(null, "Input Amount in Numerical Values", "WARNING",JOptionPane.WARNING_MESSAGE);
        }
        else
        {
            tranferAmountField.setEditable(true);    
        }
    }//GEN-LAST:event_tranferAmountFieldKeyTyped

    private void tranferMoneyButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tranferMoneyButtonActionPerformed
        if (transferAccountNumberField.getText().equals("") && tranferAmountField.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "Fill out Account Number and Amount to Transfer Money","ERROR",JOptionPane.ERROR_MESSAGE);
            transferAccountNumberField.setText("");
            tranferAmountField.setText("");
        }
        else if (transferAccountNumberField.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "Fill out Account Number","ERROR",JOptionPane.ERROR_MESSAGE);
            transferAccountNumberField.setText("");
            tranferAmountField.setText("");
        }
        else if (tranferAmountField.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "Input Amount to Transfer Money","ERROR",JOptionPane.ERROR_MESSAGE);
            transferAccountNumberField.setText("");
            tranferAmountField.setText("");
        }
        else
        { 
           int choice = JOptionPane.showConfirmDialog(null, 
                                                   "Are you sure you want to transfer to " +   
                                                    transferAccountNumberField.getText() + 
                                                    " with the amount of PHP " + tranferAmountField.getText(), 
                                                   "Transfer", 
                                                   JOptionPane.YES_NO_OPTION); 
           
           double amountToTransfer = Double.parseDouble( tranferAmountField.getText());
           
            if (choice == JOptionPane.YES_OPTION)
            {
                if (amountToTransfer > amountBalance)  
                {
                    JOptionPane.showMessageDialog(null, "Insufficient Balance",
                                                  "ERROR",JOptionPane.ERROR_MESSAGE);
                    tranferAmountField.setText("");
                    transferAccountNumberField.setText("");
                }
                else if (amountBalance - amountToTransfer < 500)
                {
                    JOptionPane.showMessageDialog(null, "Transfer Amount Exceeds the Minimum Balance Requirement", 
                                                  "WARNING",JOptionPane.WARNING_MESSAGE);
                    transferAccountNumberField.setText("");
                    tranferAmountField.setText("");
                }
                else if (amountToTransfer <= 0)
                {
                    JOptionPane.showMessageDialog(null, "Invalid Input",
                                                  "Error",JOptionPane.ERROR_MESSAGE);
                    tranferAmountField.setText("");
                    transferAccountNumberField.setText("");   
                }
                else if (amountToTransfer <= amountBalance)
                {
                    amountBalance -= amountToTransfer;
                    updateBalance();
                    JOptionPane.showMessageDialog(null, "Transfer Successfully",
                                                  "Transaction Success",JOptionPane.INFORMATION_MESSAGE);
                    tranferAmountField.setText("");
                    transferAccountNumberField.setText("");   
                }   
            }
            else if (choice == JOptionPane.NO_OPTION )
            {
                JOptionPane.showMessageDialog(null, "Transfer Cancelled", "ERROR",JOptionPane.ERROR_MESSAGE);
                tranferAmountField.setText("");
                transferAccountNumberField.setText("");
            }  
        }
        
    }//GEN-LAST:event_tranferMoneyButtonActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Account().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel accountBalance;
    private javax.swing.JLabel accountBalanceLabel;
    private javax.swing.JPanel accountBalancePanel;
    private javax.swing.JLabel accountNumber;
    private javax.swing.JLabel accountNumberTransferLabel;
    private javax.swing.JLabel amountLabel;
    private javax.swing.JTextField amountToDepositField;
    private javax.swing.JLabel amountToDepositLabel;
    private javax.swing.JTextField amountToWithdrawField;
    private javax.swing.JLabel cloverBankLabel;
    private javax.swing.JLabel cloverLabel;
    private javax.swing.JPanel deposit;
    private javax.swing.JButton depositButton;
    private javax.swing.JLabel depositLabel;
    private javax.swing.JButton depositMoneyButton;
    private javax.swing.JLabel depositWarningLabel;
    private javax.swing.JLabel depositWarningMessage;
    private javax.swing.JLabel depositWarningMessage2;
    private javax.swing.JButton exitButton;
    private javax.swing.JLabel greetingLabel;
    private javax.swing.JLabel name;
    private javax.swing.JPanel panel;
    private javax.swing.JPasswordField pinNumberField;
    private javax.swing.JLabel pinNumberLabel;
    private javax.swing.JLabel profileLabel;
    private javax.swing.JPanel rightPanel;
    private javax.swing.JTabbedPane tabbedPane;
    private javax.swing.JPanel topPanel;
    private javax.swing.JTextField tranferAmountField;
    private javax.swing.JButton tranferMoneyButton;
    private javax.swing.JPanel transfer;
    private javax.swing.JTextField transferAccountNumberField;
    private javax.swing.JLabel transferAmountLabel;
    private javax.swing.JButton transferButton;
    private javax.swing.JLabel transferLabel;
    private javax.swing.JLabel transferWarningLabel;
    private javax.swing.JLabel transferWarningMessage;
    private javax.swing.JLabel transferWarningMessage2;
    private javax.swing.JPanel viewAccount;
    private javax.swing.JButton viewAccountButton;
    private javax.swing.JPanel withdraw;
    private javax.swing.JButton withdrawButton;
    private javax.swing.JLabel withdrawLabel;
    private javax.swing.JButton withdrawMoneyButton;
    private javax.swing.JLabel withdrawWarningLabel;
    private javax.swing.JLabel withdrawWarningMessage;
    private javax.swing.JLabel withdrawWarningMessage2;
    // End of variables declaration//GEN-END:variables
}
